import React from 'react';

function Header() {
  return (
    <header className="header">
      <button className="login-btn">로그인</button>
    </header>
  );
}

export default Header;
